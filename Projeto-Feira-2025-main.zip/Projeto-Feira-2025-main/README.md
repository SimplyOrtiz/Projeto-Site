# Projeto-Feira-2025

Este projeto é um site que está sendo criado por uma equipe de 10 alunos do Terceiro ano de Desenvolvimento de Sistemas. <br>

---

> [!WARNING]
> O projeto ainda está sendo trabalhado. <br>
> Caso encontre bugs no site ou no código reporte-os para nós, e tentaremos arrumar o mais rápido o possível.

---

**Contribuidores do projeto:** *(Incompleto)*

- [@SimplyOrtiz](https://www.github.com/SimplyOrtiz) (Líder Geral do Projeto + Programador)

<!--Pesquisa e Levantamento:
- Tecnologias Agrícola
  - [@manoNoel](https://www.github.com/manoNoel)
  - [@...](https://www.github.com/)
- Comunicação
  - [@...](https://www.github.com/)
  - [@...](https://www.github.com/)
- Robótica
  - [@...](https://www.github.com/)
  - [@RenatoFirefox](https://www.github.com/RenatoFirefox)
- Tecnologias Portáteis
  - [@...](https://www.github.com/)
  - [@...](https://www.github.com/)
  
Prototipagem e Design:
- [@BurunoRodri](https://www.github.com/BurunoRodri)
- [@...](https://www.github.com/)
- [@diegadas-css](https://www.github.com/diegadas-css)
- [@...](https://www.github.com/)
- [@Samuelodeiamaika](https://www.github.com/Samuelodeiamaika)
-->
Desenvolvimento:
- [@C4rloos](https://www.github.com/C4rloos)
- [@Matheusoliveira-05](https://www.github.com/Matheusoliveira-05)
<!--- [@pedrolimah](https://www.github.com/pedrolimah)-->
